import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile, access } from 'node:fs/promises';
const code = await readFile(new URL('../dist/sw.js', import.meta.url), 'utf8');
const base = 'https://mobile.example.test';
function worker({ fail = false, redirect = false } = {}) {
  const listeners = new Map(); const stores = new Map(); const fetched = []; let offline = false;
  const path = input => new URL(typeof input === 'string' ? input : input.url, base).pathname;
  const caches = {
    async open(name) { if (!stores.has(name)) stores.set(name, new Map()); const store = stores.get(name); return { async put(url, response) { store.set(path(url), response); }, async match(url) { return store.get(path(url)); } }; },
    async keys() { return [...stores.keys()]; }, async delete(name) { return stores.delete(name); }
  };
  const context = {
    self: { location: { origin: base }, clients: { async claim() {} }, async skipWaiting() {}, addEventListener(name, handler) { listeners.set(name, handler); } },
    caches, URL, AbortController, setTimeout, clearTimeout,
    Request: class { constructor(url, options) { this.url = new URL(url, base).href; this.options = options; } },
    Response: { error: () => ({ error: true }) },
    async fetch(request) {
      fetched.push(path(request));
      if (fail || offline) throw new Error('Network unavailable');
      const url = new URL(typeof request === 'string' ? request : request.url, base).href;
      const ext = path(request).split('.').pop();
      const types = { js: 'text/javascript', css: 'text/css', html: 'text/html', webmanifest: 'application/manifest+json', png: 'image/png', svg: 'image/svg+xml' };
      return { ok: true, redirected: redirect, url, headers: { get: () => redirect ? 'text/html' : types[ext] }, body: url };
    }
  };
  vm.runInNewContext(code, context);
  return { listeners, stores, fetched, setOffline: value => offline = value };
}
async function lifecycle(w, type) { let promise; w.listeners.get(type)({ waitUntil(p) { promise = p; } }); await promise; }
async function request(w, pathname, { mode = 'cors', method = 'GET', origin = base } = {}) {
  let promise;
  w.listeners.get('fetch')({ request: { url: new URL(pathname, origin).href, mode, method }, respondWith(p) { promise = p; } });
  return promise;
}
test('manifest includes installable icons and every cached asset exists', async () => {
  const manifest = JSON.parse(await readFile(new URL('../dist/manifest.webmanifest', import.meta.url), 'utf8'));
  assert.equal(manifest.display, 'standalone'); assert.equal(manifest.scope, '/');
  assert.ok(manifest.icons.some(i => i.sizes === '192x192'));
  assert.ok(manifest.icons.some(i => i.sizes === '512x512' && i.purpose === 'maskable'));
  const w = worker(); await lifecycle(w, 'install');
  for (const asset of w.fetched) await access(new URL('../dist' + asset, import.meta.url));
});
test('complete cache serves the app shell and scripts offline, including start-url queries', async () => {
  const w = worker(); await lifecycle(w, 'install'); await lifecycle(w, 'activate'); w.setOffline(true);
  const shell = await request(w, '/?source=homescreen', { mode: 'navigate' });
  assert.equal(shell.body, `${base}/index.html`);
  assert.equal((await request(w, '/app.js')).body, `${base}/app.js`);
});
test('login callbacks, API calls, posts and other origins are never handled by offline cache', async () => {
  const w = worker(); await lifecycle(w, 'install'); w.setOffline(true);
  for (const url of ['/callback', '/signin-with-chatgpt', '/api/private']) assert.equal(await request(w, url, { mode: 'navigate' }), undefined);
  assert.equal(await request(w, '/app.js', { method: 'POST' }), undefined);
  assert.equal(await request(w, '/app.js', { origin: 'https://other.example.test' }), undefined);
});
test('failed downloads or auth redirects cannot create a partial application cache', async () => {
  for (const options of [{ fail: true }, { redirect: true }]) {
    const w = worker(options); await assert.rejects(lifecycle(w, 'install'));
    assert.equal(w.stores.size, 0);
  }
});
test('activation cleans only this app caches and reports actual offline readiness', async () => {
  const w = worker(); await lifecycle(w, 'install');
  w.stores.set('yiyu-mobile-old', new Map()); w.stores.set('unrelated-app', new Map());
  await lifecycle(w, 'activate'); assert.equal(w.stores.has('yiyu-mobile-old'), false); assert.equal(w.stores.has('unrelated-app'), true);
  let promise, status;
  w.listeners.get('message')({ data: { type: 'OFFLINE_STATUS' }, ports: [{ postMessage(data) { status = data; } }], waitUntil(p) { promise = p; } });
  await promise; assert.equal(status.ready, true);
});
