import { STORAGE_KEY, PROJECTS, uid, localDate, createState, freshTimer, remainingSeconds, startTimer, pauseTimer, finishTimer, statsFor, validateState } from './core.js';

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
const paths = {
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.93 4.93l1.41 1.41m11.32 11.32 1.41 1.41m0-14.14-1.41 1.41M6.34 17.66l-1.41 1.41"/>',
  list: '<rect x="4" y="3" width="16" height="18" rx="3"/><path d="M9 8h7M9 12h7M9 16h5M7 8h.01M7 12h.01M7 16h.01"/>',
  note: '<path d="M14 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-9M14 3v7h7M14 3l7 7M7 14h9M7 17h6"/>',
  chart: '<path d="M4 3v18h17M8 16v-4m5 4V8m5 8V5"/>',
  settings: '<path d="m9.5 3-.6 2.1-2 .9-2.1-.5-2.3 4 1.5 1.6v2l-1.5 1.6 2.3 4 2.1-.5 2 .9.6 2.1h5l.6-2.1 2-.9 2.1.5 2.3-4-1.5-1.6v-2L21 9.5l-2.3-4-2.1.5-2-.9L14 3z"/><circle cx="12" cy="12" r="3"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  play: '<path d="m8 5 11 7-11 7z"/>',
  pause: '<path d="M8 5v14M16 5v14" stroke-width="3"/>',
  reset: '<path d="M3 10a9 9 0 1 1 2.6 8.4M3 4v6h6"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  circleCheck: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  leaf: '<path d="M20 3c-9 0-16 4-16 11a6 6 0 0 0 6 6c7 0 10-8 10-17Z"/><path d="M4 21 15 10"/>',
  arrowRight: '<path d="M4 12h16m-6-6 6 6-6 6"/>',
  'arrow-right': '<path d="M4 12h16m-6-6 6 6-6 6"/>',
  'arrow-up-right': '<path d="M6 18 18 6M6 6h12v12"/>',
  expand: '<path d="M8 3H3v5m13-5h5v5M3 16v5h5m8 0h5v-5"/>',
  shrink: '<path d="M3 8h5V3m8 0v5h5M8 21v-5H3m18 0h-5v5"/>',
  pen: '<path d="m15 4 5 5M4 15 16 3a2.1 2.1 0 0 1 3 0l2 2a2.1 2.1 0 0 1 0 3L9 20l-6 1 1-6Z"/>',
  headphones: '<path d="M3 14v-3a9 9 0 0 1 18 0v3M3 13h3v8H5a2 2 0 0 1-2-2v-6Zm18 0h-3v8h1a2 2 0 0 0 2-2v-6Z"/>',
  x: '<path d="m6 6 12 12M6 18 18 6"/>',
  trash: '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
  pin: '<path d="m16 3 5 5-4 2-3 5-5-5 5-3 2-4ZM9 10l-3 3 5 5 3-3M8 16l-5 5"/>',
  sort: '<path d="M7 4v16m-3-3 3 3 3-3M14 5h6m-6 5h4m-4 5h2"/>',
  download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
  upload: '<path d="M12 16V4m-5 5 5-5 5 5M4 16v5h16v-5"/>',
  spark: '<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z"/>',
  shield: '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/><path d="m8 12 3 3 5-6"/>',
  flag: '<path d="M5 21V3m0 1c5-4 9 4 14 0v10c-5 4-9-4-14 0"/>',
};
const icon = (name, extra = '') => `<svg ${extra} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.leaf}</svg>`;
$$('[data-icon]').forEach(el => el.innerHTML = icon(el.dataset.icon));
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const projectClass = p => ({ 工作: 'work', 学习: 'learn', 生活: 'life' }[p] || 'work');
const timeLabel = value => new Date(value).toLocaleString('zh-CN', { month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false });
const shortDate = value => value ? `${Number(value.slice(5, 7))}月${Number(value.slice(8, 10))}日` : '';
const formattedTime = seconds => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;

let storageOK = true;
let recovered = false;
let state;
try {
  const stored = localStorage.getItem(STORAGE_KEY);
  try { state = stored ? validateState(JSON.parse(stored), { restoreTimer: true }) : createState(); }
  catch { recovered = true; localStorage.setItem(`${STORAGE_KEY}.recovery`, stored); state = createState(); }
} catch { state = createState(); storageOK = false; }
let view = ['today', 'tasks', 'notes', 'stats'].includes(location.hash.slice(1)) ? location.hash.slice(1) : 'today';
let tab = 'pending';
let project = 'all';
let sort = 'priority';
let editingTaskId = null;
let editingNoteId = null;
let day = localDate();
let toastTimeout;
let draftTimeout;
let completeResult = null;
let confirmResolve = null;
let audioContext = null;
let lastSaveError = false;
let ownsTimer = true;

function updateSaveStatus() {
  $('#save-status').classList.toggle('error', !storageOK);
  $('#save-status span').textContent = storageOK ? '已保存在本机' : '尚未保存，请导出备份';
  $('#save-status').title = storageOK ? '数据仅保存在当前浏览器，可在偏好与数据中导出备份' : '浏览器存储不可用，请立即导出备份以免丢失数据';
}
function persist({ quiet = false } = {}) {
  state.updatedAt = new Date().toISOString();
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); storageOK = true; lastSaveError = false; }
  catch {
    storageOK = false;
    if (!quiet && !lastSaveError) toast('本机保存失败，请在偏好与数据中导出备份。', null, true);
    lastSaveError = true;
  }
  updateSaveStatus();
}
function toast(message, undo = null, error = false) {
  clearTimeout(toastTimeout);
  $('#toast-region').innerHTML = `<div class="toast${error ? ' error' : ''}">${icon(error ? 'flag' : 'circleCheck')}<span>${escape(message)}</span>${undo ? '<button id="toast-undo">撤销</button>' : ''}</div>`;
  if (undo) $('#toast-undo').onclick = () => { undo(); $('#toast-region').innerHTML = ''; };
  toastTimeout = setTimeout(() => $('#toast-region').innerHTML = '', undo ? 7000 : 4200);
}
function showDialog(id) {
  const el = $(id);
  if (!el.open) el.showModal();
}
async function confirmAction(title, description, accept = '确认') {
  if (confirmResolve) return false;
  $('#confirm-title').textContent = title;
  $('#confirm-description').textContent = description;
  $('#confirm-accept').textContent = accept;
  showDialog('#confirm-dialog');
  return new Promise(resolve => confirmResolve = resolve);
}
$('#confirm-accept').onclick = () => { const resolve = confirmResolve; confirmResolve = null; $('#confirm-dialog').close(); resolve?.(true); };
$('#confirm-cancel').onclick = () => $('#confirm-dialog').close();
$('#confirm-dialog').addEventListener('close', () => { const resolve = confirmResolve; confirmResolve = null; resolve?.(false); });
$$('[data-close]').forEach(button => button.onclick = () => button.closest('dialog').close());
$$('dialog').forEach(dialog => dialog.addEventListener('click', event => {
  if (event.target !== dialog) return;
  const rect = dialog.getBoundingClientRect();
  if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
}));

function navigate(next, nextProject = 'all') {
  view = next; project = nextProject; tab = 'pending';
  history.replaceState(null, '', `#${view}`);
  render();
}
$$('.nav-item[data-view]').forEach(button => button.onclick = () => navigate(button.dataset.view));
$$('[data-project]').forEach(button => button.onclick = () => navigate('tasks', button.dataset.project));
$('.brand').onclick = event => { event.preventDefault(); navigate('today'); };
window.addEventListener('hashchange', () => {
  const next = location.hash.slice(1);
  if (['today', 'tasks', 'notes', 'stats'].includes(next)) { view = next; project = 'all'; render(); }
});

function render() {
  document.body.dataset.view = view;
  const titles = { today: ['A LITTLE SPACE, A BETTER DAY', '把今天，留给重要的事', '不用着急。从一件小事开始，找到自己的节奏。', '今天', 'sun'], tasks: ['SMALL STEPS, MEANINGFUL PROGRESS', '每一小步，都有它的意义', '把心里的待办放下来，给每一件事一个位置。', '任务清单', 'list'], notes: ['LET YOUR THOUGHTS FIND A HOME', '好想法，值得被留住', '收集生活里的灵光，等它慢慢长成自己的样子。', '灵感便笺', 'note'], stats: ['YOUR EFFORT, QUIETLY GROWING', '认真投入的时间，会留下痕迹', '不必与谁比较，看见自己一点一滴的积累。', '专注统计', 'chart'] };
  const info = titles[view];
  if (view === 'today') { info[1] = '今天，专心一点'; info[2] = '把重要的事，放在手心。'; }
  if (view === 'tasks') { info[1] = '小事，也认真对待'; info[2] = '写下来，再一步一步做好。'; }
  if (view === 'notes') { info[1] = '让灵感，有个落点'; info[2] = '随时记下生活里的一点光。'; }
  if (view === 'stats') { info[1] = '每一刻，都有回响'; info[2] = '按自己的节奏，看见一点点积累。'; }
  $('#page-eyebrow').textContent = info[0];
  $('#page-title').innerHTML = `${info[1]}<span>。</span>`;
  $('#page-subtitle').textContent = info[2];
  $('#breadcrumb-text').textContent = info[3];
  $('#breadcrumb-icon').innerHTML = icon(info[4]);
  $('#top-date').textContent = new Date().toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' });
  $$('.nav-item[data-view]').forEach(b => { b.classList.toggle('active', b.dataset.view === view); b.setAttribute('aria-current', b.dataset.view === view ? 'page' : 'false'); b.setAttribute('aria-label', titles[b.dataset.view][3]); });
  $$('.project-nav').forEach(b => b.classList.toggle('active', view === 'tasks' && b.dataset.project === project));
  $('#today-count').textContent = state.tasks.filter(t => !t.done && (!t.due || t.due <= localDate())).length;
  const newButton = $('#new-task');
  newButton.setAttribute('aria-label', view === 'notes' ? '新建便笺' : '新建任务');
  newButton.innerHTML = `${icon('plus')}<span>${view === 'notes' ? '新建便笺' : '新建任务'}</span><kbd>N</kbd>`;
  newButton.onclick = () => view === 'notes' ? openNote() : openTask();
  $('#view-content').innerHTML = view === 'today' ? renderToday() : view === 'tasks' ? renderTasksView() : view === 'notes' ? renderNotes() : renderStats();
  bindView();
  renderTimer();
}
function activeTask() { return state.tasks.find(t => t.id === state.activeTaskId && !t.done); }
function renderToday() {
  const task = activeTask();
  const stats = statsFor(state);
  const goal = Math.min(100, stats.todayMinutes / state.settings.goal * 100);
  return `<section class="focus-hero"><div class="hero-copy"><div class="hero-eyebrow">${icon('spark')}此刻，只做一件事</div><h2>${escape(task?.title || '给自己留一段专注的时间')}</h2><div class="hero-description">${task ? `<i class="project-dot ${projectClass(task.project)}"></i>${escape(task.project)}<span class="hero-divider">/</span>预计 ${task.estimate} 分钟` : '清空杂念，让重要的事自然浮现'}</div><button id="hero-focus" class="button primary hero-button">${icon('play')}<span>${state.timer.status === 'running' ? '回到专注' : '开始这一刻'}</span>${icon('arrowRight')}</button></div><span class="hero-leaf-caption">SLOW DOWN & GROW</span><div class="hero-art" aria-hidden="true"><svg viewBox="0 0 190 210" fill="none"><circle cx="111" cy="104" r="69" fill="#e0e8d4"/><circle cx="111" cy="104" r="59" stroke="#c8d4b6" stroke-width=".8"/><path d="M65 190v-68a46 46 0 0 1 92 0v68" fill="#d5e0c5"/><path d="M76 190v-66a35 35 0 0 1 70 0v66M86 190v-65a25 25 0 0 1 50 0v65M97 190v-64a14 14 0 0 1 28 0v64" stroke="#b8c9a0" stroke-width="1"/><path d="M111 190v-64" stroke="#aabd90"/><path d="M46 188c16-8 25-22 25-42-16 3-30 17-25 42Z" fill="#9fb784"/><path d="M46 188c-13-4-21-15-22-29 14 1 25 13 22 29Z" fill="#b4c69e"/><path d="M46 197v-37" stroke="#8ca56f"/><path d="M16 198h158" stroke="#b8c9a0"/><circle cx="161" cy="62" r="4" fill="#c5cea8"/><path d="m35 91 3 6 6 3-6 3-3 6-3-6-6-3 6-3 3-6Z" fill="#c0cba7"/></svg></div></section><section class="summary-strip" aria-label="今日概览"><div class="summary-item"><div class="summary-top">${icon('clock')}今日专注</div><div class="summary-value">${stats.todayMinutes}<span class="summary-unit">分钟</span></div><div class="summary-bottom">${stats.todayRounds ? `完成了 ${stats.todayRounds} 段认真投入` : '每一分钟，都是新的开始'}</div></div><div class="summary-item"><div class="summary-top">${icon('circleCheck')}完成任务</div><div class="summary-value">${stats.completedToday}<span class="summary-unit">件</span></div><div class="summary-bottom">小小的完成，也值得肯定</div></div><div class="summary-item"><div class="summary-top">${icon('flag')}每日目标</div><div class="summary-value">${Math.round(goal)}<span class="summary-unit">%</span></div><div class="summary-progress"><span style="width:${goal}%"></span></div><div class="summary-bottom">${state.settings.goal} 分钟，按自己的节奏来</div></div></section>${taskPanel(true)}${weeklyChart(stats, false)}`;
}
function filteredTasks(today = false) {
  let tasks = state.tasks.filter(t => (!today || !t.due || t.due <= localDate()) && (project === 'all' || t.project === project));
  const counts = { all: tasks.length, pending: tasks.filter(t => !t.done).length, done: tasks.filter(t => t.done).length };
  tasks = tasks.filter(t => tab === 'all' || (tab === 'pending' ? !t.done : t.done));
  tasks.sort((a, b) => {
    if (a.done !== b.done) return Number(a.done) - Number(b.done);
    if (sort === 'priority') { const rank = { high: 0, normal: 1, low: 2 }; const delta = rank[a.priority] - rank[b.priority]; if (delta) return delta; }
    return sort === 'date' ? (a.due || '9999').localeCompare(b.due || '9999') || a.createdAt.localeCompare(b.createdAt) : a.createdAt.localeCompare(b.createdAt);
  });
  return { tasks, counts };
}
function taskPanel(today = false) {
  const { tasks, counts } = filteredTasks(today);
  const hasSamples = !state.sampleDismissed && state.tasks.some(t => t.sample);
  return `<section class="task-panel panel"><div class="panel-heading"><h2>${today ? '今天的清单' : project === 'all' ? '所有任务' : `${escape(project)}空间`}<span class="heading-count">${counts.pending} 件待完成</span></h2><span class="heading-small">一点一点，慢慢来</span></div><div class="task-tabs" role="group" aria-label="任务筛选">${[['pending', '待完成'], ['all', '全部'], ['done', '已完成']].map(([key, label]) => `<button data-tab="${key}" class="${tab === key ? 'active' : ''}" aria-pressed="${tab === key}">${label}<span class="tab-count">${counts[key]}</span></button>`).join('')}<div class="task-tools"><button id="sort-toggle" class="sort-toggle" title="切换排序方式">${icon('sort')}<span>${sort === 'priority' ? '优先级' : '计划日期'}</span></button></div></div>${hasSamples ? '<div class="sample-banner"><span>这是一份示例清单，可以随心编辑。</span><button id="clear-samples">从空白开始</button></div>' : ''}<div class="task-list">${tasks.length ? tasks.map(taskRow).join('') : `<div class="empty-state">${icon('leaf')}<h3>${tab === 'done' ? '每个完成，都值得记住' : counts.all && tab === 'pending' ? '清单空了，心也轻了' : '给重要的事，留个位置'}</h3><p>${tab === 'done' ? '完成的任务会在这里和你再次相遇。' : '写下一件小事，就是一个很好的开始。'}</p></div>`}</div><button class="add-task-row" id="add-task-inline">${icon('plus')}添加一件小事<kbd>按 N 快速添加</kbd></button><div class="task-panel-footer">${icon('shield')}所有改变自动保存在当前浏览器，记得定期备份。</div></section>`;
}
function taskRow(t) {
  const overdue = !t.done && t.due && t.due < localDate();
  return `<article class="task-row${t.done ? ' done' : ''}"><button class="task-check" data-check="${escape(t.id)}" aria-label="${t.done ? '恢复任务' : '完成任务'}：${escape(t.title)}" aria-pressed="${t.done}">${t.done ? icon('check') : ''}</button><div class="task-info"><button class="task-title-button" data-edit="${escape(t.id)}" title="编辑：${escape(t.title)}">${escape(t.title)}</button><div class="task-meta"><span class="task-tag ${projectClass(t.project)}-tag"><i class="project-dot ${projectClass(t.project)}"></i>${escape(t.project)}</span><span class="meta-dot">•</span><span class="task-estimate">${icon('clock')}${t.estimate} 分钟</span>${t.priority === 'high' ? '<span class="meta-dot">•</span><span class="priority-high">优先做</span>' : ''}${t.due && (overdue || view === 'tasks') ? `<span class="meta-dot">•</span><span class="${overdue ? 'overdue' : ''}">${overdue ? '待跟进 · ' : ''}${shortDate(t.due)}</span>` : ''}${t.sample ? '<span class="meta-dot">•</span><span>示例</span>' : ''}</div></div><div class="task-actions">${!t.done ? `<button class="icon-button focus-task${t.id === state.activeTaskId ? ' selected' : ''}" data-focus="${escape(t.id)}" title="为这件事专注" aria-label="专注：${escape(t.title)}">${icon('play')}</button>` : ''}<button class="icon-button edit-task" data-edit="${escape(t.id)}" title="编辑任务" aria-label="编辑：${escape(t.title)}">${icon('pen')}</button><button class="icon-button delete-task" data-delete="${escape(t.id)}" title="删除任务" aria-label="删除：${escape(t.title)}">${icon('trash')}</button></div></article>`;
}
function renderTasksView() {
  return `<div class="project-filters">${['all', ...PROJECTS].map(p => `<button class="project-filter${project === p ? ' active' : ''}" data-filter="${p}" aria-pressed="${project === p}">${p === 'all' ? '全部空间' : `<i class="project-dot ${projectClass(p)}"></i>${p}`}</button>`).join('')}</div>${taskPanel()}`;
}
function weeklyChart(stats, large) {
  const max = Math.max(...stats.buckets.map(b => b.minutes), 60);
  const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
  const bars = stats.buckets.map(b => {
    const today = b.date === localDate();
    const height = b.minutes ? Math.max(6, b.minutes / max * 100) : 0;
    return `<div class="bar-column${today ? ' today' : ''}" title="${shortDate(b.date)}：${b.minutes} 分钟"><div class="bar-track"><div class="bar-fill" style="height:${height}%">${b.minutes ? `<span class="bar-value">${b.minutes}′</span>` : ''}</div></div><span class="bar-label">${today ? '今天' : '周' + weekdays[new Date(`${b.date}T12:00:00`).getDay()]}</span></div>`;
  }).join('');
  return `<section class="week-panel panel${large ? ' stats-chart' : ''}"><div class="weekly-heading"><h2>${icon('chart')}近七天的专注足迹</h2>${large ? `<span class="heading-small">${shortDate(stats.buckets[0].date)} — ${shortDate(stats.buckets[6].date)}</span>` : `<button id="see-stats" class="text-button">查看统计${icon('arrow-up-right')}</button>`}</div><div class="weekly-bars" role="img" aria-label="近七天专注分钟数：${stats.buckets.map(b => `${shortDate(b.date)} ${b.minutes}分钟`).join('，')}">${bars}</div><div class="week-caption"><span>${stats.weekMinutes ? `七天累计 ${stats.weekMinutes} 分钟，时间在见证你的成长。` : '第一段专注之后，这里会留下你的足迹。'}</span><span>只记录完整结束的专注</span></div></section>`;
}
function renderNotes() {
  const notes = [...state.notes].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt.localeCompare(a.updatedAt));
  return `<div class="notes-toolbar"><span>${notes.length} 个被留住的想法</span><span>先置顶，再按最近编辑排列</span></div>${notes.length ? `<div class="notes-grid">${notes.map(n => `<article class="note-card">${n.pinned ? `<div class="note-pin">${icon('pin')}</div>` : ''}<div class="note-body">${escape(n.content)}</div><div class="note-bottom"><span>${timeLabel(n.updatedAt)}</span><div class="note-actions"><button class="icon-button" data-pin-note="${escape(n.id)}" title="${n.pinned ? '取消置顶' : '置顶便笺'}" aria-label="${n.pinned ? '取消置顶' : '置顶便笺'}" aria-pressed="${n.pinned}">${icon('pin')}</button><button class="icon-button" data-edit-note="${escape(n.id)}" title="编辑便笺" aria-label="编辑便笺">${icon('pen')}</button><button class="icon-button" data-delete-note="${escape(n.id)}" title="删除便笺" aria-label="删除便笺">${icon('trash')}</button></div></div></article>`).join('')}</div>` : `<section class="panel empty-state notes-empty">${icon('note')}<h3>好想法，总在不经意间出现</h3><p>一句摘录、一个灵感、下一次想去的地方。<br>在这里，给它们一个温柔的落点。</p><button class="button secondary" id="first-note">${icon('plus')}写下第一个想法</button></section>`}`;
}
function renderStats() {
  const stats = statsFor(state);
  const allDays = new Set(state.sessions.map(s => localDate(s.completedAt))).size;
  const completed = state.tasks.filter(t => t.done && !t.sample).length;
  const metric = (name, value, unit, hint, image) => `<div class="stat-card"><div class="stat-label">${icon(image)}${name}</div><div class="summary-value">${value}<span class="summary-unit">${unit}</span></div><div class="stat-description">${hint}</div></div>`;
  const sessions = [...state.sessions].sort((a, b) => b.completedAt.localeCompare(a.completedAt)).slice(0, 30);
  return `<div class="stats-grid">${metric('累计专注', stats.totalMinutes, '分钟', '每一段投入，都有意义', 'clock')}${metric('近七天专注', stats.weekMinutes, '分钟', `今天已完成 ${stats.todayRounds} 轮专注`, 'chart')}${metric('已完成任务', completed, '件', '真实的进步，来自一点一滴', 'circleCheck')}${metric('有过专注的日子', allDays, '天', '按自己的步调，慢慢向前', 'sun')}</div>${weeklyChart(stats, true)}<section class="history-panel panel"><div class="panel-heading"><h2>最近的专注时刻</h2><span class="heading-small">最近 30 条</span></div>${sessions.length ? `<div class="history-list">${sessions.map(s => `<div class="history-item"><div class="history-icon">${icon('leaf')}</div><div class="history-content"><div class="history-title">${escape(s.taskTitle)}</div><div class="history-date">${timeLabel(s.completedAt)}${s.project ? ` · ${escape(s.project)}` : ''}</div></div><div class="history-duration">${s.minutes}<small>分钟</small></div></div>`).join('')}</div>` : `<div class="empty-state">${icon('clock')}<h3>还没有专注记录</h3><p>完成一轮计时，记录会自动出现在这里。<br>暂停或重置的计时不会计入。</p></div>`}</section>`;
}

function bindView() {
  $$('[data-tab]').forEach(b => b.onclick = () => { tab = b.dataset.tab; render(); });
  $$('[data-filter]').forEach(b => b.onclick = () => { project = b.dataset.filter; render(); });
  $$('[data-edit]').forEach(b => b.onclick = () => openTask(b.dataset.edit));
  $$('[data-check]').forEach(b => b.onclick = () => toggleTask(b.dataset.check));
  $$('[data-focus]').forEach(b => b.onclick = () => focusTask(b.dataset.focus));
  $$('[data-delete]').forEach(b => b.onclick = () => deleteTask(b.dataset.delete));
  $$('[data-edit-note]').forEach(b => b.onclick = () => openNote(b.dataset.editNote));
  $$('[data-delete-note]').forEach(b => b.onclick = () => deleteNote(b.dataset.deleteNote));
  $$('[data-pin-note]').forEach(b => b.onclick = () => { const n = state.notes.find(n => n.id === b.dataset.pinNote); n.pinned = !n.pinned; persist(); render(); });
  if ($('#sort-toggle')) $('#sort-toggle').onclick = () => { sort = sort === 'priority' ? 'date' : 'priority'; render(); };
  if ($('#add-task-inline')) $('#add-task-inline').onclick = () => openTask();
  if ($('#clear-samples')) $('#clear-samples').onclick = clearSamples;
  if ($('#see-stats')) $('#see-stats').onclick = () => navigate('stats');
  if ($('#first-note')) $('#first-note').onclick = () => openNote();
  if ($('#hero-focus')) $('#hero-focus').onclick = async () => {
    if (state.timer.status === 'running') { showImmersive(); return; }
    if (state.timer.mode !== 'focus' && !await switchMode('focus')) return;
    toggleTimer(); showImmersive();
  };
}
function openTask(id = null) {
  editingTaskId = id;
  const task = state.tasks.find(t => t.id === id);
  $('#task-dialog-title').textContent = task ? '给这件事一点细节' : '新的一件事';
  $('#mobile-delete-task').hidden = !task;
  $('#task-form').reset();
  $('#task-title').setCustomValidity('');
  $('#task-title').value = task?.title || '';
  $('#task-detail').value = task?.detail || '';
  $('#task-project').value = task?.project || (project !== 'all' ? project : '工作');
  $('#task-priority').value = task?.priority || 'normal';
  $('#task-date').value = task?.due ?? localDate();
  $('#task-estimate').value = String(task?.estimate || 25);
  if (!$('#task-estimate').value) $('#task-estimate').value = '25';
  showDialog('#task-dialog');
  $('#task-title').focus();
}
$('#task-form').onsubmit = event => {
  event.preventDefault();
  const title = $('#task-title').value.trim();
  if (!title) { $('#task-title').setCustomValidity('先写下一件想完成的事。'); $('#task-title').reportValidity(); return; }
  const task = state.tasks.find(t => t.id === editingTaskId);
  const fields = { title, detail: $('#task-detail').value.trim(), project: $('#task-project').value, priority: $('#task-priority').value, due: $('#task-date').value, estimate: Number($('#task-estimate').value) };
  if (task) Object.assign(task, fields, { sample: false });
  else { const fresh = { id: uid(), ...fields, done: false, createdAt: new Date().toISOString(), completedAt: null, sample: false }; state.tasks.push(fresh); if (!activeTask()) state.activeTaskId = fresh.id; }
  persist(); $('#task-dialog').close();
  if (view === 'notes' || view === 'stats') view = 'tasks';
  if (project !== 'all' && fields.project !== project) project = 'all';
  if (view === 'today' && fields.due && fields.due > localDate()) view = 'tasks';
  history.replaceState(null, '', `#${view}`);
  tab = 'pending'; render(); toast(task ? '细节已保存。' : '新的一件事，已经有了位置。');
};
$('#task-title').oninput = () => $('#task-title').setCustomValidity('');
function toggleTask(id) {
  const task = state.tasks.find(t => t.id === id);
  if (!task) return;
  task.done = !task.done; task.completedAt = task.done ? new Date().toISOString() : null; task.sample = false;
  if (task.done && state.activeTaskId === id) state.activeTaskId = state.tasks.find(t => !t.done)?.id || null;
  const done = task.done;
  persist(); render(); toast(done ? '又完成了一件事，给自己一点肯定。' : '已放回清单，按自己的节奏来。', () => { task.done = !done; task.completedAt = task.done ? new Date().toISOString() : null; persist(); render(); });
}
function deleteTask(id) {
  const index = state.tasks.findIndex(t => t.id === id);
  if (index < 0) return;
  const [task] = state.tasks.splice(index, 1);
  const wasActive = state.activeTaskId === id;
  if (wasActive) state.activeTaskId = state.tasks.find(t => !t.done)?.id || null;
  persist(); render(); toast('任务已移走。', () => { state.tasks.splice(index, 0, task); if (wasActive) state.activeTaskId = id; persist(); render(); });
}
async function clearSamples() {
  if (!await confirmAction('从自己的第一件事开始', '只移除未改动的示例任务。你自己创建和编辑过的内容会保留。', '清除示例')) return;
  state.tasks = state.tasks.filter(t => !t.sample);
  state.sampleDismissed = true;
  if (!activeTask()) state.activeTaskId = state.tasks.find(t => !t.done)?.id || null;
  persist(); render(); renderSampleAction(); toast('空间准备好了，写下自己的第一件事吧。');
}
async function focusTask(id) {
  const task = state.tasks.find(t => t.id === id && !t.done);
  if (!task) return;
  if (state.timer.startedAt && state.timer.taskId !== id) {
    if (!await confirmAction('换一件事专注？', '当前这轮计时会重置，未完成的时间不会计入统计。', '切换任务')) return;
    state.timer = freshTimer(state.settings);
  }
  state.activeTaskId = id;
  if (state.timer.mode !== 'focus') state.timer = freshTimer(state.settings);
  persist(); render();
  if (state.timer.status !== 'running') toggleTimer();
  toast(`正在为「${task.title}」专注。`);
}

function openNote(id = null) {
  editingNoteId = id;
  const note = state.notes.find(n => n.id === id);
  $('#note-dialog-title').textContent = note ? '再添一点想法' : '留住一个想法';
  $('#note-content').value = note?.content || '';
  $('#note-content').setCustomValidity('');
  showDialog('#note-dialog'); $('#note-content').focus();
}
$('#note-form').onsubmit = event => {
  event.preventDefault();
  const content = $('#note-content').value.trim();
  if (!content) { $('#note-content').setCustomValidity('写下一点想法再保存吧。'); $('#note-content').reportValidity(); return; }
  const note = state.notes.find(n => n.id === editingNoteId);
  if (note) Object.assign(note, { content, updatedAt: new Date().toISOString() });
  else addNote(content);
  persist(); $('#note-dialog').close(); render(); toast('想法已留住，之后再慢慢展开。');
};
$('#note-content').oninput = () => $('#note-content').setCustomValidity('');
function addNote(content) { const stamp = new Date().toISOString(); state.notes.push({ id: uid(), content, createdAt: stamp, updatedAt: stamp, pinned: false }); }
function deleteNote(id) {
  const index = state.notes.findIndex(n => n.id === id);
  if (index < 0) return;
  const [note] = state.notes.splice(index, 1);
  persist(); render(); toast('便笺已移走。', () => { state.notes.splice(index, 0, note); persist(); render(); });
}
$('#quick-note-input').value = state.draft;
$('#quick-note-input').oninput = () => {
  state.draft = $('#quick-note-input').value;
  $('#draft-status').textContent = '正在保存…';
  clearTimeout(draftTimeout);
  draftTimeout = setTimeout(() => { persist(); $('#draft-status').textContent = storageOK ? '草稿已保存' : '草稿尚未保存'; }, 450);
};
$('#save-note').onclick = () => {
  const content = $('#quick-note-input').value.trim();
  if (!content) { $('#quick-note-input').focus(); toast('先写下一点想法吧。'); return; }
  clearTimeout(draftTimeout); addNote(content); state.draft = ''; $('#quick-note-input').value = '';
  $('#draft-status').textContent = '草稿自动保存'; persist(); render(); toast('想法已存入灵感便笺。');
};

function unlockAudio() {
  if (!state.settings.sound) return;
  try { audioContext ||= new (window.AudioContext || window.webkitAudioContext)(); audioContext.resume().catch(() => {}); } catch { /* audio is optional */ }
}
function chime() {
  if (!state.settings.sound || !audioContext) return;
  try {
    [523.25, 659.25, 783.99].forEach((frequency, i) => {
      const oscillator = audioContext.createOscillator(); const gain = audioContext.createGain(); const at = audioContext.currentTime + i * .19;
      oscillator.type = 'sine'; oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0, at); gain.gain.linearRampToValueAtTime(.12, at + .02); gain.gain.exponentialRampToValueAtTime(.001, at + .9);
      oscillator.connect(gain); gain.connect(audioContext.destination); oscillator.start(at); oscillator.stop(at + 1);
    });
  } catch { /* audio is optional */ }
}
function toggleTimer() {
  if (state.timer.status === 'running' && remainingSeconds(state.timer) === 0) { checkCompletion(); return; }
  if (state.timer.status === 'running') state.timer = pauseTimer(state.timer);
  else { unlockAudio(); state.timer = startTimer(state.timer, state.activeTaskId); ownsTimer = true; }
  persist(); renderTimer();
  if ($('#hero-focus')) $('#hero-focus').querySelector('span').textContent = state.timer.status === 'running' ? '回到专注' : '开始这一刻';
}
async function switchMode(mode) {
  if (state.timer.mode === mode) return true;
  if (state.timer.startedAt && !await confirmAction('切换计时模式？', '当前这轮计时会重置，未完成的时间不会计入统计。', '切换模式')) return false;
  state.timer = freshTimer(state.settings, mode); persist(); renderTimer(); return true;
}
$('#focus-mode').onclick = () => switchMode('focus');
$('#break-mode').onclick = () => switchMode('break');
$('#timer-toggle').onclick = toggleTimer;
$('#immersive-toggle').onclick = toggleTimer;
$('#timer-reset').onclick = async () => {
  if (state.timer.startedAt && !await confirmAction('重新开始这一轮？', '这一轮未完成的时间不会计入统计。准备好了，可以随时重新开始。', '重置计时')) return;
  state.timer = freshTimer(state.settings, state.timer.mode); persist(); render();
};
function renderTimer() {
  const timer = state.timer;
  const remaining = remainingSeconds(timer);
  const running = timer.status === 'running';
  const paused = timer.status === 'paused';
  const focus = timer.mode === 'focus';
  const time = formattedTime(remaining);
  const targetTask = timer.startedAt ? state.tasks.find(t => t.id === timer.taskId) : activeTask();
  const buttonLabel = running ? '暂停一下' : paused ? '继续这一轮' : focus ? '开始专注' : '开始休息';
  $('#timer-display').textContent = time;
  $('#timer-display').setAttribute('aria-label', `剩余${Math.floor(remaining / 60)}分${remaining % 60}秒`);
  $('#ring-progress').style.strokeDashoffset = String(615.752 * (1 - remaining / timer.duration));
  $('#focus-mode').classList.toggle('selected', focus); $('#focus-mode').setAttribute('aria-pressed', String(focus));
  $('#break-mode').classList.toggle('selected', !focus); $('#break-mode').setAttribute('aria-pressed', String(!focus));
  $('#focus-duration-label').textContent = state.settings.focus;
  $('#break-duration-label').textContent = state.settings.break;
  $('#timer-kicker').textContent = focus ? '给自己一段专注' : '让心轻轻休息一下';
  $('#timer-state-label').classList.toggle('running', running);
  $('#timer-state-label').innerHTML = `<i></i>${running ? focus ? '沉浸在这一刻' : '慢慢呼吸，不用着急' : paused ? '歇一口气，随时继续' : '准备好就开始'}`;
  $('#timer-task').textContent = focus ? targetTask?.title || '自由专注，也很好' : '喝点水，看看窗外吧';
  $('#timer-task').title = $('#timer-task').textContent;
  $('#timer-toggle').innerHTML = `${icon(running ? 'pause' : 'play')}<span>${buttonLabel}</span>`;
  $('#immersive-time').textContent = time;
  $('#immersive-task').textContent = focus ? targetTask?.title || '给自己一段专注' : '此刻，安心休息';
  $('#immersive-toggle').innerHTML = `${icon(running ? 'pause' : 'play')}<span>${buttonLabel}</span>`;
  $('#immersive-caption').textContent = paused ? '停一停也很好，准备好再继续。' : focus ? '呼吸，放松，把注意力带回这一刻。' : '把目光从屏幕移开，让思绪自由走一走。';
  document.title = running ? `${time} · ${focus ? '专注中' : '休息中'} · 一隅` : '一隅 · 随身工作台';
  updateMobileFocus(timer, remaining, buttonLabel);
}
function showImmersive() { renderTimer(); showDialog('#immersive-dialog'); }
$('#immersive-open').onclick = showImmersive;
function checkCompletion() {
  if (!ownsTimer) return;
  const result = finishTimer(state);
  if (!result) return;
  completeResult = result;
  persist(); render(); chime();
  $('#immersive-dialog').close();
  $('#completion-heading').textContent = result.mode === 'focus' ? '这一刻，做得很好。' : '休息好了，重新出发。';
  $('#completion-copy').textContent = result.mode === 'focus' ? `刚刚的 ${result.session?.minutes || state.settings.focus} 分钟，已成为你的专注足迹。给自己一点肯定，也给大脑一点休息。` : '不用急着填满接下来的时间。准备好了，再认真做一件小事。';
  const task = state.tasks.find(t => t.id === result.taskId && !t.done);
  $('#completion-task-action').innerHTML = result.mode === 'focus' && task ? `<button id="mark-focused-task" class="button secondary">${icon('check')}这件事完成了</button>` : '';
  if ($('#mark-focused-task')) $('#mark-focused-task').onclick = () => { toggleTask(task.id); $('#completion-task-action').innerHTML = '<p>已标记完成。又是小小的一步。</p>'; };
  $('#completion-next').innerHTML = `${result.mode === 'focus' ? '休息一下' : '开始新一轮'}${icon('arrowRight')}`;
  showDialog('#complete-dialog');
}
$('#completion-next').onclick = () => {
  const mode = completeResult?.mode === 'focus' ? 'break' : 'focus';
  state.timer = freshTimer(state.settings, mode); $('#complete-dialog').close(); toggleTimer(); render();
};
setInterval(() => { if (day !== localDate()) { day = localDate(); render(); } checkCompletion(); renderTimer(); }, 1000);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { checkCompletion(); renderTimer(); } else if (draftTimeout) { clearTimeout(draftTimeout); persist({ quiet: true }); } });
window.addEventListener('pagehide', () => { clearTimeout(draftTimeout); persist({ quiet: true }); });

function renderSampleAction() {
  $('#sample-actions').innerHTML = state.tasks.some(t => t.sample) ? '<button id="settings-clear-samples" class="sample-remove">移除未改动的示例任务</button>' : '';
  if ($('#settings-clear-samples')) $('#settings-clear-samples').onclick = clearSamples;
}
function openSettings() {
  $('#setting-focus').value = state.settings.focus; $('#setting-break').value = state.settings.break;
  $('#setting-goal').value = state.settings.goal; $('#setting-sound').checked = state.settings.sound;
  renderSampleAction(); showDialog('#settings-dialog');
}
$('#settings-open').onclick = openSettings;
$('.avatar').setAttribute('role', 'button'); $('.avatar').setAttribute('tabindex', '0'); $('.avatar').setAttribute('aria-label', '打开偏好与数据');
$('.avatar').onclick = openSettings;
$('.avatar').onkeydown = event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openSettings(); } };
$('#settings-form').onsubmit = event => {
  event.preventDefault();
  state.settings = { focus: Number($('#setting-focus').value), break: Number($('#setting-break').value), goal: Number($('#setting-goal').value), sound: $('#setting-sound').checked };
  if (state.timer.status === 'idle') state.timer = freshTimer(state.settings, state.timer.mode);
  persist(); render(); $('#settings-dialog').close(); toast('已调整为你的节奏。');
};
function download(data, filename) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = filename;
  document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
$('#export-data').onclick = () => {
  download({ ...state, exportedAt: new Date().toISOString(), app: '一隅 YIYU' }, `一隅-备份-${localDate()}.json`);
  toast('备份已开始下载，请妥善保存。');
};
$('#import-data').onclick = () => $('#import-file').click();
$('#import-file').onchange = async event => {
  const file = event.target.files[0]; event.target.value = '';
  if (!file) return;
  let imported;
  try {
    if (file.size > 5 * 1024 * 1024) throw new Error('文件超过 5 MB，请选择较小的一隅备份。');
    imported = validateState(JSON.parse(await file.text()));
  } catch (error) { toast(error instanceof SyntaxError ? '无法读取此文件，请选择一隅导出的 JSON 备份。' : error.message, null, true); return; }
  if (!await confirmAction('恢复这个空间？', `备份含 ${imported.tasks.length} 件任务、${imported.notes.length} 张便笺、${imported.sessions.length} 条专注记录。恢复会替换当前数据，计时将重置。`, '恢复备份')) return;
  const previous = state;
  state = imported; ownsTimer = true;
  $('#quick-note-input').value = state.draft; clearTimeout(draftTimeout);
  persist(); render(); $('#settings-dialog').close();
  toast('空间已恢复。', () => { state = previous; $('#quick-note-input').value = state.draft; persist(); render(); });
};

function openSearch() { $('#search-input').value = ''; showDialog('#search-dialog'); renderSearch(); $('#search-input').focus(); }
$('#search-open').onclick = openSearch;
$('#search-input').oninput = renderSearch;
function renderSearch() {
  const query = $('#search-input').value.trim().toLocaleLowerCase();
  const tasks = state.tasks.filter(t => !query || `${t.title} ${t.detail} ${t.project}`.toLocaleLowerCase().includes(query)).slice(0, 8);
  const notes = state.notes.filter(n => !query || n.content.toLocaleLowerCase().includes(query)).slice(0, 6);
  $('#search-results').innerHTML = !query && !tasks.length && !notes.length ? '<div class="search-empty">任务和便笺会在这里被找到。</div>' : tasks.length || notes.length ? [...tasks.map(t => `<button class="search-result" data-search-task="${escape(t.id)}"><span>${icon(t.done ? 'circleCheck' : 'list')}</span><div class="search-result-copy"><div class="search-result-title">${escape(t.title)}</div><div class="search-result-meta">任务 · ${escape(t.project)} · ${t.done ? '已完成' : '待完成'}</div></div>${icon('arrow-up-right', 'class="result-arrow"')}</button>`), ...notes.map(n => `<button class="search-result" data-search-note="${escape(n.id)}"><span>${icon('note')}</span><div class="search-result-copy"><div class="search-result-title">${escape(n.content.slice(0, 90))}</div><div class="search-result-meta">便笺 · ${timeLabel(n.updatedAt)}</div></div>${icon('arrow-up-right', 'class="result-arrow"')}</button>`)].join('') : `<div class="search-empty">没有找到「${escape(query)}」，试试换个词。</div>`;
  $$('[data-search-task]').forEach(b => b.onclick = () => { $('#search-dialog').close(); openTask(b.dataset.searchTask); });
  $$('[data-search-note]').forEach(b => b.onclick = () => { $('#search-dialog').close(); openNote(b.dataset.searchNote); });
}
document.addEventListener('keydown', event => {
  const editing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); if (!$('dialog[open]')) openSearch(); return; }
  if (editing || $('dialog[open]') || event.ctrlKey || event.altKey || event.metaKey || event.repeat) return;
  if (event.key.toLowerCase() === 'n') { event.preventDefault(); view === 'notes' ? openNote() : openTask(); }
  if (event.code === 'Space' && document.activeElement === document.body) { event.preventDefault(); toggleTimer(); }
});
window.addEventListener('storage', event => {
  if (event.key !== STORAGE_KEY || !event.newValue) return;
  try {
    const incoming = validateState(JSON.parse(event.newValue), { restoreTimer: true });
    if (incoming.updatedAt <= state.updatedAt) return;
    state = incoming; ownsTimer = true;
    if (document.activeElement !== $('#quick-note-input')) $('#quick-note-input').value = state.draft;
    render();
  } catch { /* an invalid external write cannot replace working data */ }
});

let installPrompt = null;
let offlineReady = false;
let screenLock = null;
let screenLockPending = false;
const installKey = 'yiyu.mobile.install-dismissed';
const standalone = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
try { $('#install-card').hidden = standalone || localStorage.getItem(installKey) === 'true'; } catch { $('#install-card').hidden = standalone; }
$('.data-settings').insertAdjacentHTML('beforeend', '<button id="mobile-install-settings" class="button secondary mobile-install-settings">'+icon('download')+'安装到主屏幕</button>');
$('#task-form').insertAdjacentHTML('beforeend', '<button type="button" id="mobile-delete-task" class="mobile-delete-task" hidden>移除这件事</button>');
$('#mobile-delete-task').onclick = () => { if (!editingTaskId) return; deleteTask(editingTaskId); $('#task-dialog').close(); };
$('#mobile-focus-open').onclick = showImmersive;
$('#mobile-timer-pill').onclick = showImmersive;
$('#mobile-focus-mode').onclick = () => switchMode('focus');
$('#mobile-break-mode').onclick = () => switchMode('break');
$('#mobile-reset').onclick = () => $('#timer-reset').click();
$$('[data-focus-minutes]').forEach(button => button.onclick = async () => {
  const minutes = Number(button.dataset.focusMinutes);
  if (state.timer.startedAt && !await confirmAction('重新选择这一刻的时长？', '当前这一轮会重置，未完成的时间不会计入统计。', '调整时长')) return;
  state.settings.focus = minutes;
  state.timer = freshTimer(state.settings, 'focus');
  persist(); renderTimer();
});
function updateMobileFocus(timer, remaining) {
  const focus = timer.mode === 'focus';
  $('#mobile-focus-mode').classList.toggle('selected', focus);
  $('#mobile-focus-mode').setAttribute('aria-pressed', String(focus));
  $('#mobile-break-mode').classList.toggle('selected', !focus);
  $('#mobile-break-mode').setAttribute('aria-pressed', String(!focus));
  $$('.mobile-presets button').forEach(b => {
    b.disabled = timer.status !== 'idle';
    b.classList.toggle('selected', focus && Number(b.dataset.focusMinutes) * 60 === timer.duration);
    b.setAttribute('aria-pressed', String(focus && Number(b.dataset.focusMinutes) * 60 === timer.duration));
  });
  $('#mobile-timer-pill').hidden = timer.status === 'idle';
  $('#mobile-pill-time').textContent = formattedTime(remaining);
  $('#mobile-pill-state').textContent = timer.status === 'paused' ? '已暂停' : focus ? '专注中' : '休息中';
  syncScreenLock();
}
if (!('wakeLock' in navigator)) $('#wake-lock-row').hidden = true;
$('#wake-lock-toggle').onchange = syncScreenLock;
async function syncScreenLock() {
  const wanted = $('#wake-lock-toggle').checked && state.timer.status === 'running' && document.visibilityState === 'visible' && $('#immersive-dialog').open;
  if (!wanted) { const lock = screenLock; screenLock = null; if (lock) await lock.release().catch(() => {}); return; }
  if (screenLock || screenLockPending || !navigator.wakeLock) return;
  screenLockPending = true;
  try {
    const lock = await navigator.wakeLock.request('screen');
    if (!$('#wake-lock-toggle').checked || !$('#immersive-dialog').open || state.timer.status !== 'running') { await lock.release(); return; }
    screenLock = lock;
    lock.addEventListener('release', () => { if (screenLock === lock) screenLock = null; });
  } catch { $('#wake-lock-toggle').checked = false; toast('当前无法保持常亮，请检查省电设置。'); }
  finally { screenLockPending = false; }
}
$('#immersive-dialog').addEventListener('close', syncScreenLock);
document.addEventListener('visibilitychange', syncScreenLock);
async function showInstall() {
  if (installPrompt) {
    const prompt = installPrompt; installPrompt = null;
    try { await prompt.prompt(); await prompt.userChoice; } catch { showDialog('#install-dialog'); }
    return;
  }
  showDialog('#install-dialog'); updateOfflineStatus();
}
$('#mobile-install').onclick = showInstall;
$('#mobile-install-settings').onclick = showInstall;
$('#install-dismiss').onclick = () => { $('#install-card').hidden = true; try { localStorage.setItem(installKey, 'true'); } catch {} };
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installPrompt = event; });
window.addEventListener('appinstalled', () => { $('#install-card').hidden = true; installPrompt = null; toast('一隅已放到主屏幕，随时回来坐坐。'); });
function updateOfflineStatus() {
  $('#offline-status').textContent = offlineReady ? '离线已准备好。断网后，任务、计时和便笺仍可使用。' : navigator.onLine === false ? '当前离线。已打开的页面可以继续使用，重新打开前请先联网。' : '首次联网打开后，将准备离线使用。';
}
function inspectOffline(worker) {
  if (!worker || typeof MessageChannel === 'undefined') return;
  const channel = new MessageChannel();
  const timeout = setTimeout(() => { channel.port1.close(); }, 5000);
  channel.port1.onmessage = event => { clearTimeout(timeout); channel.port1.close(); offlineReady = event.data?.ready === true; updateOfflineStatus(); };
  worker.postMessage({ type: 'OFFLINE_STATUS' }, [channel.port2]);
}
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js', { scope: './', updateViaCache: 'none' }).then(registration => {
      if (registration.active) inspectOffline(registration.active);
      return navigator.serviceWorker.ready;
    }).then(registration => inspectOffline(registration.active)).catch(() => {
      $('#offline-status').textContent = '离线暂未准备好，请联网使用。添加到主屏幕仍可按浏览器菜单操作。';
    });
  });
  navigator.serviceWorker.addEventListener('controllerchange', () => inspectOffline(navigator.serviceWorker.controller));
}
window.addEventListener('online', updateOfflineStatus);
window.addEventListener('offline', () => { updateOfflineStatus(); toast(offlineReady ? '已离线，仍可继续使用和保存。' : '已离线，当前页面仍可继续使用。'); });
persist(); render(); checkCompletion();
if (recovered) toast('旧数据读取异常，已保留原始副本，请勿清理浏览器数据。', null, true);
else if (!storageOK) toast('浏览器暂时无法保存数据，请使用导出备份。', null, true);
