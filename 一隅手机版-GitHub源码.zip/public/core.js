export const STORAGE_KEY = 'yiyu.workspace.v1';
export const PROJECTS = ['工作', '学习', '生活'];
export const DEFAULT_SETTINGS = { focus: 25, break: 5, goal: 120, sound: true };
export const uid = () => globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
export const localDate = (value = new Date()) => {
  const d = new Date(value);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
export function freshTimer(settings = DEFAULT_SETTINGS, mode = 'focus') {
  return { mode, duration: settings[mode] * 60, remaining: settings[mode] * 60, status: 'idle', endAt: null, startedAt: null, taskId: null, id: uid() };
}
export function createState(now = new Date()) {
  const today = localDate(now);
  const stamp = new Date(now).toISOString();
  const make = (title, project, priority, estimate, done = false) => ({ id: uid(), title, detail: '', project, priority, estimate, due: today, done, createdAt: stamp, completedAt: done ? stamp : null, sample: true });
  const tasks = [make('写下今天最重要的一件事', '工作', 'high', 25), make('为一个新想法留十分钟', '学习', 'normal', 15), make('给忙碌留一点空白', '生活', 'low', 15)];
  return { version: 1, tasks, notes: [], sessions: [], settings: { ...DEFAULT_SETTINGS }, draft: '', activeTaskId: tasks[0].id, timer: freshTimer(), sampleDismissed: false, updatedAt: stamp };
}
export function remainingSeconds(timer, now = Date.now()) {
  return timer.status === 'running' && timer.endAt ? Math.max(0, Math.ceil((timer.endAt - now) / 1000)) : Math.max(0, timer.remaining);
}
export function startTimer(timer, taskId = null, now = Date.now()) {
  const remaining = remainingSeconds(timer, now);
  return { ...timer, status: 'running', remaining, endAt: now + remaining * 1000, startedAt: timer.startedAt || now, taskId: timer.startedAt ? timer.taskId : taskId };
}
export function pauseTimer(timer, now = Date.now()) {
  return { ...timer, remaining: remainingSeconds(timer, now), status: 'paused', endAt: null };
}
export function finishTimer(state, now = Date.now()) {
  const timer = state.timer;
  if (timer.status !== 'running' || remainingSeconds(timer, now) > 0) return null;
  let session = null;
  if (timer.mode === 'focus' && !state.sessions.some(s => s.id === timer.id)) {
    const task = state.tasks.find(t => t.id === timer.taskId);
    session = { id: timer.id, minutes: timer.duration / 60, taskId: timer.taskId, taskTitle: task?.title || '自由专注', project: task?.project || null, completedAt: new Date(timer.endAt).toISOString() };
    state.sessions.push(session);
  }
  state.timer = freshTimer(state.settings, timer.mode);
  return { mode: timer.mode, session, taskId: timer.taskId };
}
export function daysBack(count = 7, now = new Date()) {
  return Array.from({ length: count }, (_, i) => {
    const date = new Date(now);
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() - count + 1 + i);
    return localDate(date);
  });
}
export function statsFor(state, now = new Date()) {
  const days = daysBack(7, now);
  const today = localDate(now);
  const buckets = days.map(date => ({ date, minutes: state.sessions.filter(s => localDate(s.completedAt) === date).reduce((sum, s) => sum + s.minutes, 0) }));
  const todaySessions = state.sessions.filter(s => localDate(s.completedAt) === today);
  const completedToday = state.tasks.filter(t => t.done && !t.sample && t.completedAt && localDate(t.completedAt) === today).length;
  return { buckets, todayMinutes: todaySessions.reduce((n, s) => n + s.minutes, 0), todayRounds: todaySessions.length, completedToday, weekMinutes: buckets.reduce((n, b) => n + b.minutes, 0), totalMinutes: state.sessions.reduce((n, s) => n + s.minutes, 0) };
}

const text = (v, length = 10000) => typeof v === 'string' ? v.slice(0, length) : '';
const validStamp = v => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v) && Number.isFinite(Date.parse(v));
const number = (v, min, max, fallback) => typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max ? v : fallback;
const dateOnly = v => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && localDate(new Date(`${v}T12:00:00`)) === v ? v : '';
export function validateState(raw, { restoreTimer = false } = {}) {
  if (!raw || raw.version !== 1 || !Array.isArray(raw.tasks) || !Array.isArray(raw.notes) || !Array.isArray(raw.sessions)) throw new Error('这不是有效的一隅备份文件。');
  if (raw.tasks.length > 10000 || raw.notes.length > 5000 || raw.sessions.length > 50000) throw new Error('备份中的记录过多，无法恢复。');
  const stamp = new Date().toISOString();
  const ensureIds = items => {
    const used = new Set();
    return items.map(item => { if (!item.id || used.has(item.id)) item.id = uid(); used.add(item.id); return item; });
  };
  const tasks = ensureIds(raw.tasks.filter(t => t && typeof t.title === 'string' && t.title.trim()).map(t => ({ id: text(t.id, 100) || uid(), title: text(t.title, 180).trim(), detail: text(t.detail, 4000), project: PROJECTS.includes(t.project) ? t.project : '生活', priority: ['high', 'normal', 'low'].includes(t.priority) ? t.priority : 'normal', estimate: number(t.estimate, 1, 180, 25), due: dateOnly(t.due), done: t.done === true, sample: t.sample === true, createdAt: validStamp(t.createdAt) ? t.createdAt : stamp, completedAt: t.done === true && validStamp(t.completedAt) ? t.completedAt : null })));
  const notes = ensureIds(raw.notes.filter(n => n && typeof n.content === 'string' && n.content.trim()).map(n => ({ id: text(n.id, 100) || uid(), content: text(n.content), createdAt: validStamp(n.createdAt) ? n.createdAt : stamp, updatedAt: validStamp(n.updatedAt) ? n.updatedAt : stamp, pinned: n.pinned === true })));
  const sessions = ensureIds(raw.sessions.filter(s => s && validStamp(s.completedAt) && number(s.minutes, 1, 180, null) !== null).map(s => ({ id: text(s.id, 100) || uid(), minutes: s.minutes, taskId: text(s.taskId, 100) || null, taskTitle: text(s.taskTitle, 180) || '自由专注', project: PROJECTS.includes(s.project) ? s.project : null, completedAt: s.completedAt })));
  const prefs = raw.settings || {};
  const settings = { focus: Math.round(number(prefs.focus, 1, 180, 25)), break: Math.round(number(prefs.break, 1, 60, 5)), goal: Math.round(number(prefs.goal, 1, 720, 120)), sound: prefs.sound !== false };
  let timer = freshTimer(settings);
  const rt = raw.timer;
  if (restoreTimer && rt && ['focus', 'break'].includes(rt.mode) && ['idle', 'running', 'paused'].includes(rt.status)) {
    const duration = number(rt.duration, 60, 10800, settings[rt.mode] * 60);
    const remaining = number(rt.remaining, 0, duration, duration);
    const endAt = number(rt.endAt, 1, Date.now() + 10800000, null);
    const startedAt = number(rt.startedAt, 1, Date.now(), null);
    timer = { id: text(rt.id, 100) || uid(), mode: rt.mode, duration, remaining, status: rt.status === 'running' && !endAt ? 'paused' : rt.status, endAt, startedAt, taskId: tasks.some(t => t.id === rt.taskId) ? rt.taskId : null };
  }
  return { version: 1, tasks, notes, sessions, settings, timer, draft: text(raw.draft), activeTaskId: tasks.some(t => t.id === raw.activeTaskId && !t.done) ? raw.activeTaskId : null, sampleDismissed: raw.sampleDismissed === true, updatedAt: validStamp(raw.updatedAt) ? raw.updatedAt : stamp };
}
