const CACHE = 'yiyu-mobile-v1.0.2';
const ASSETS = ['/index.html', '/app.js', '/core.js', '/styles.css', '/mobile.css', '/manifest.webmanifest', '/favicon.svg', '/icons/icon-192.png', '/icons/icon-512.png', '/icons/icon-maskable-512.png', '/icons/apple-touch-icon.png'];
const allowed = new Set(ASSETS);
function validAsset(response, url) {
  if (!response.ok || response.redirected || new URL(response.url).origin !== self.location.origin) return false;
  const type = response.headers.get('Content-Type') || '';
  if (url.endsWith('.js')) return /javascript/.test(type);
  if (url.endsWith('.css')) return /text\/css/.test(type);
  if (url.endsWith('.html')) return /text\/html/.test(type);
  if (url.endsWith('.png')) return /image\/png/.test(type);
  if (url.endsWith('.svg')) return /image\/svg/.test(type);
  if (url.endsWith('.webmanifest')) return /json|manifest/.test(type);
  return false;
}
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const entries = await Promise.all(ASSETS.map(async url => {
      const response = await fetch(new Request(url, { credentials: 'same-origin', redirect: 'error', cache: 'reload' }));
      if (!validAsset(response, url)) throw new Error('Offline assets are not ready');
      return [url, response];
    }));
    const cache = await caches.open(CACHE);
    await Promise.all(entries.map(([url, response]) => cache.put(url, response)));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('yiyu-mobile-') && key !== CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (request.mode === 'navigate' && (url.pathname === '/' || url.pathname === '/index.html')) {
    event.respondWith((async () => {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 4500);
        try {
          const response = await fetch(request, { signal: controller.signal });
          if (!response.ok) throw new Error('Offline fallback');
          return response;
        } finally { clearTimeout(timeout); }
      } catch {
        return await (await caches.open(CACHE)).match('/index.html') || Response.error();
      }
    })());
  } else if (allowed.has(url.pathname) && url.pathname !== '/index.html') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE);
      return await cache.match(url.pathname) || fetch(request);
    })());
  }
});
self.addEventListener('message', event => {
  if (event.data?.type === 'OFFLINE_STATUS' && event.ports[0]) {
    event.waitUntil((async () => {
      const cache = await caches.open(CACHE);
      const ready = (await Promise.all(ASSETS.map(url => cache.match(url)))).every(Boolean);
      event.ports[0].postMessage({ ready });
    })());
  }
});
