import test from 'node:test';
import assert from 'node:assert/strict';
import { createState, freshTimer, startTimer, pauseTimer, remainingSeconds, finishTimer, localDate, daysBack, statsFor, validateState } from '../public/core.js';

test('a first visit offers examples without fabricating historical activity', () => {
  const state = createState();
  assert.equal(state.tasks.length, 3);
  assert.ok(state.tasks.every(t => t.sample && !t.done));
  assert.equal(state.sessions.length, 0);
  assert.equal(statsFor(state).totalMinutes, 0);
  assert.equal(statsFor(state).completedToday, 0);
});
test('timer uses its deadline after background throttling, then resumes from pause', () => {
  const timer = startTimer(freshTimer(), 'task', 100000);
  assert.equal(remainingSeconds(timer, 160000), 1440);
  const paused = pauseTimer(timer, 190000);
  assert.equal(paused.remaining, 1410);
  assert.equal(remainingSeconds(paused, 600000), 1410);
  const resumed = startTimer(paused, 'different-task', 600000);
  assert.equal(resumed.taskId, 'task');
  assert.equal(resumed.endAt, 2010000);
  assert.equal(remainingSeconds(resumed, 9999999), 0);
});
test('focus completion records the deadline and cannot double count', () => {
  const state = createState();
  state.timer = startTimer(freshTimer({ focus: 1 }), state.tasks[0].id, 100000);
  assert.equal(finishTimer(state, 159999), null);
  const result = finishTimer(state, 300000);
  assert.equal(result.mode, 'focus');
  assert.equal(state.sessions.length, 1);
  assert.equal(state.sessions[0].minutes, 1);
  assert.equal(state.sessions[0].completedAt, new Date(160000).toISOString());
  assert.equal(state.sessions[0].taskTitle, state.tasks[0].title);
  assert.equal(finishTimer(state, 300001), null);
  assert.equal(state.sessions.length, 1);
});
test('breaks and incomplete rounds never inflate focus statistics', () => {
  const state = createState();
  state.timer = startTimer(freshTimer(state.settings, 'break'), null, 100000);
  assert.equal(finishTimer(state, 500000).mode, 'break');
  assert.equal(state.sessions.length, 0);
  state.timer = pauseTimer(startTimer(freshTimer(), null, 100000), 110000);
  assert.equal(finishTimer(state, 9999999), null);
  assert.equal(state.sessions.length, 0);
});
test('valid local state restores paused and running timers; imported backups start idle', () => {
  const state = createState();
  state.timer = startTimer(freshTimer(), state.tasks[0].id);
  const restored = validateState(JSON.parse(JSON.stringify(state)), { restoreTimer: true });
  assert.equal(restored.timer.status, 'running');
  assert.equal(restored.timer.endAt, state.timer.endAt);
  const backup = validateState(state);
  assert.equal(backup.timer.status, 'idle');
  state.timer.status = 'paused'; state.timer.remaining = 120;
  assert.equal(validateState(state, { restoreTimer: true }).timer.remaining, 120);
});
test('backup validation rejects unrelated files and strips unsafe or malformed fields', () => {
  assert.throws(() => validateState({}), /有效/);
  const state = createState();
  state.settings = { focus: -20, break: Infinity, goal: '200', sound: false };
  state.tasks[0].due = '2026-02-30';
  state.tasks[0].project = '<script>';
  state.tasks[0].extra = 'untrusted';
  state.tasks.push({ id: state.tasks[0].id, title: 'duplicate ID' });
  state.tasks.push({ title: '   ' });
  state.sessions.push({ completedAt: 'invalid', minutes: 99 });
  const clean = validateState(state);
  assert.deepEqual(clean.settings, { focus: 25, break: 5, goal: 120, sound: false });
  assert.equal(clean.tasks[0].due, '');
  assert.equal(clean.tasks[0].project, '生活');
  assert.equal(clean.tasks[0].extra, undefined);
  assert.notEqual(clean.tasks[0].id, clean.tasks[3].id);
  assert.equal(clean.tasks.length, 4);
  assert.equal(clean.sessions.length, 0);
});
test('seven-day buckets work across months and attribute completed tasks to local dates', () => {
  const now = new Date(2026, 0, 3, 10);
  assert.deepEqual(daysBack(7, now), ['2025-12-28', '2025-12-29', '2025-12-30', '2025-12-31', '2026-01-01', '2026-01-02', '2026-01-03']);
  const state = createState(now);
  state.sessions = [
    { id: '1', minutes: 25, completedAt: new Date(2026, 0, 3, 9).toISOString() },
    { id: '2', minutes: 45, completedAt: new Date(2025, 11, 31, 9).toISOString() },
    { id: '3', minutes: 60, completedAt: new Date(2025, 11, 20, 9).toISOString() },
  ];
  Object.assign(state.tasks[0], { sample: false, done: true, completedAt: new Date(2026, 0, 3, 9).toISOString() });
  const stats = statsFor(state, now);
  assert.equal(stats.todayMinutes, 25);
  assert.equal(stats.todayRounds, 1);
  assert.equal(stats.weekMinutes, 70);
  assert.equal(stats.totalMinutes, 130);
  assert.equal(stats.completedToday, 1);
  assert.equal(localDate(now), '2026-01-03');
});
test('a dangling active task and an invalid timer cannot enter restored state', () => {
  const state = createState();
  state.activeTaskId = 'missing';
  state.timer = { mode: 'focus', status: 'running', endAt: 'bad', remaining: 1500, duration: 1500, taskId: 'missing' };
  const clean = validateState(state, { restoreTimer: true });
  assert.equal(clean.activeTaskId, null);
  assert.equal(clean.timer.status, 'paused');
  assert.equal(clean.timer.taskId, null);
});

