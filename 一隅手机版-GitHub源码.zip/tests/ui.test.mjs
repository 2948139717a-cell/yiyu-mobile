import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { JSDOM, VirtualConsole } from 'jsdom';
import * as core from '../public/core.js';

const html = await readFile(new URL('../public/index.html', import.meta.url), 'utf8');
const source = await readFile(new URL('../public/app.js', import.meta.url), 'utf8');
function app(stored = null) {
  const logs = [];
  const virtualConsole = new VirtualConsole();
  virtualConsole.on('jsdomError', e => logs.push(e.message));
  const dom = new JSDOM(html, { url: 'http://127.0.0.1:52173/', runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole });
  const { window: w } = dom;
  w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
  w.HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); this.dispatchEvent(new w.Event('close')); };
  if (stored) w.localStorage.setItem(core.STORAGE_KEY, stored);
  const names = Object.keys(core);
  for (const name of names) w[`__core_${name}`] = core[name];
  const script = source.replace(/^import .* from '\.\/core.js';/, `const { ${names.join(', ')} } = { ${names.map(n => `${n}: window.__core_${n}`).join(', ')} };`);
  try { w.eval(script); } catch (error) { w.close(); console.error(error.stack); throw error; }
  const $ = s => w.document.querySelector(s);
  const click = s => { assert.ok($(s), `Missing ${s}`); $(s).click(); };
  const submit = s => $(s).dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
  const state = () => JSON.parse(w.localStorage.getItem(core.STORAGE_KEY));
  return { w, dom, $, click, submit, state, logs };
}

test('mobile UI starts, creates, edits, completes and undoes a task', () => {
  const a = app();
  try {
    assert.equal(a.$('#today-count').textContent, '3');
    a.click('#new-task');
    a.$('#task-title').value = '验收任务 <test>';
    a.$('#task-detail').value = '检查保存与转义';
    a.submit('#task-form');
    const task = a.state().tasks.find(t => t.title === '验收任务 <test>');
    assert.ok(task);
    assert.ok(a.$('.task-list').textContent.includes('验收任务 <test>'));
    assert.equal(a.$('.task-list test'), null);
    a.click(`[data-edit="${task.id}"]`);
    a.$('#task-title').value = '修改后的任务';
    a.submit('#task-form');
    a.click(`[data-check="${task.id}"]`);
    assert.equal(a.state().tasks.find(t => t.id === task.id).done, true);
    a.click('#toast-undo');
    assert.equal(a.state().tasks.find(t => t.id === task.id).done, false);
    a.click(`[data-delete="${task.id}"]`);
    assert.equal(a.state().tasks.some(t => t.id === task.id), false);
    a.click('#toast-undo');
    assert.equal(a.state().tasks.some(t => t.id === task.id), true);
    assert.deepEqual(a.logs, []);
  } finally { a.dom.window.close(); }
});
test('notes save, search, edit, pin, delete and restore without executing markup', () => {
  const a = app();
  try {
    a.click('[data-view="notes"]'); a.click('#new-task');
    a.$('#note-content').value = '灵感 <img src=x onerror="bad()">'; a.submit('#note-form');
    const note = a.state().notes[0]; assert.ok(note);
    assert.equal(a.$('.note-body img'), null);
    a.click(`[data-pin-note="${note.id}"]`); assert.equal(a.state().notes[0].pinned, true);
    a.click('#search-open'); a.$('#search-input').value = '灵感'; a.$('#search-input').dispatchEvent(new a.w.Event('input'));
    assert.ok(a.$(`[data-search-note="${note.id}"]`)); a.click(`[data-search-note="${note.id}"]`);
    a.$('#note-content').value = '更新的灵感'; a.submit('#note-form'); assert.equal(a.state().notes[0].content, '更新的灵感');
    a.click(`[data-delete-note="${note.id}"]`); assert.equal(a.state().notes.length, 0);
    a.click('#toast-undo'); assert.equal(a.state().notes.length, 1);
    assert.deepEqual(a.logs, []);
  } finally { a.dom.window.close(); }
});
test('timer controls and immersive exit preserve the active round through a reload', () => {
  const a = app(); let saved;
  try {
    a.click('#settings-open'); a.$('#setting-sound').checked = false; a.submit('#settings-form');
    a.click('#timer-toggle'); assert.equal(a.state().timer.status, 'running');
    a.click('#immersive-open'); assert.equal(a.$('#immersive-dialog').open, true);
    a.click('.immersive-close'); assert.equal(a.$('#immersive-dialog').open, false);
    assert.equal(a.state().timer.status, 'running');
    a.click('#timer-toggle'); assert.equal(a.state().timer.status, 'paused');
    saved = a.w.localStorage.getItem(core.STORAGE_KEY);
    assert.equal(a.state().sessions.length, 0);
    assert.deepEqual(a.logs, []);
  } finally { a.dom.window.close(); }
  const b = app(saved);
  try { assert.equal(b.state().timer.status, 'paused'); assert.equal(b.state().sessions.length, 0); } finally { b.dom.window.close(); }
});
test('all pages and settings render; future tasks stay outside today', () => {
  const a = app();
  try {
    a.click('#new-task'); a.$('#task-title').value = '未来计划'; a.$('#task-date').value = '2099-01-01'; a.submit('#task-form');
    assert.equal(a.$('#breadcrumb-text').textContent, '任务清单');
    a.click('[data-view="today"]'); assert.equal(a.$('.task-list').textContent.includes('未来计划'), false);
    a.click('[data-view="stats"]'); assert.ok(a.$('.stats-grid')); assert.ok(a.$('.history-panel'));
    a.click('#settings-open'); a.$('#setting-focus').value = '40'; a.$('#setting-goal').value = '160'; a.submit('#settings-form');
    assert.equal(a.state().settings.focus, 40); assert.equal(a.$('#timer-display').textContent, '40:00');
    assert.deepEqual(a.logs, []);
  } finally { a.dom.window.close(); }
});
test('mobile focus tab, presets, return pill and reset work without changing pages', async () => {
  const a = app();
  try {
    a.click('#mobile-focus-open'); assert.equal(a.$('#immersive-dialog').open, true);
    a.click('[data-focus-minutes="15"]'); assert.equal(a.state().settings.focus, 15); assert.equal(a.$('#immersive-time').textContent, '15:00');
    a.click('#settings-open'); a.$('#setting-sound').checked = false; a.submit('#settings-form');
    a.click('#immersive-toggle'); assert.equal(a.state().timer.status, 'running'); assert.equal(a.$('#mobile-timer-pill').hidden, false);
    assert.equal(a.$('[data-focus-minutes="25"]').disabled, true);
    a.click('.immersive-close'); assert.equal(a.state().timer.status, 'running');
    a.click('#mobile-timer-pill'); assert.equal(a.$('#immersive-dialog').open, true);
    a.click('#mobile-reset'); assert.equal(a.$('#confirm-dialog').open, true);
    a.click('#confirm-accept');
    await new Promise(setImmediate);
    assert.equal(a.state().timer.status, 'idle'); assert.equal(a.$('#mobile-timer-pill').hidden, true);
    assert.equal(a.state().sessions.length, 0);
    a.click('#mobile-break-mode'); assert.equal(a.$('#immersive-time').textContent, '05:00');
    assert.deepEqual(a.logs, []);
  } finally { a.dom.window.close(); }
});
test('mobile edit sheet can delete an unfinished task and undo it', () => {
  const a = app();
  try {
    a.click('#new-task'); assert.equal(a.$('#mobile-delete-task').hidden, true);
    a.$('#task-title').value = '手机待移除任务'; a.submit('#task-form');
    const id = a.state().tasks.find(t => t.title === '手机待移除任务').id;
    a.click(`[data-edit="${id}"]`); assert.equal(a.$('#mobile-delete-task').hidden, false);
    a.click('#mobile-delete-task'); assert.equal(a.state().tasks.some(t => t.id === id), false);
    a.click('#toast-undo'); assert.equal(a.state().tasks.some(t => t.id === id), true);
  } finally { a.dom.window.close(); }
});
test('installation guide remains accessible after dismissing the banner', () => {
  const a = app();
  try {
    a.click('#install-dismiss'); assert.equal(a.$('#install-card').hidden, true);
    a.click('#settings-open'); a.click('#mobile-install-settings');
    assert.equal(a.$('#install-dialog').open, true);
    assert.ok(a.$('#install-dialog').textContent.includes('iPhone'));
    assert.ok(a.$('#install-dialog').textContent.includes('安卓'));
    assert.equal(a.$('#wake-lock-row').hidden, true);
    assert.deepEqual(a.logs, []);
  } finally { a.dom.window.close(); }
});

